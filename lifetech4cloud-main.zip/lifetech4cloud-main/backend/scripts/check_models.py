import app.models\nprint('has_ads_claims:', hasattr(app.models.User, 'ads_claims'))\nprint('has_AdsClaim:', hasattr(app.models, 'AdsClaim'))\n
