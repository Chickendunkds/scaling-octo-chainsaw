export { default } from "./AdsCoin";
